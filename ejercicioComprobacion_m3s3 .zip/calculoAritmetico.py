

#creando variables

a = 20
b = 30

# operacion aritmetica
sum = (a + b)

# imprimiendo resultado
print("La suma es: " ,sum)


#Thelma Delgado operacion aritmetica ejercicio comprobacion m3s3